package com.dao;

import com.model.User;
import com.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {

	public boolean validate(User user) throws ClassNotFoundException {
		boolean status = false;

		try (Connection connection = DBUtil.getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?")) {
			preparedStatement.setString(1, user.getUsername());
			preparedStatement.setString(2, user.getPassword());

			ResultSet rs = preparedStatement.executeQuery();
			status = rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return status;
	}

	public void registerUser(User user) throws ClassNotFoundException {
		String INSERT_USERS_SQL = "INSERT INTO users (username, password, email) VALUES (?, ?, ?);";

		try (Connection connection = DBUtil.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
			preparedStatement.setString(1, user.getUsername());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getEmail());

			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public boolean checkUserExists(String username) throws ClassNotFoundException {
		boolean exists = false;
		String CHECK_USER_SQL = "SELECT username FROM users WHERE username = ?";

		try (Connection connection = DBUtil.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(CHECK_USER_SQL)) {
			preparedStatement.setString(1, username);

			ResultSet rs = preparedStatement.executeQuery();
			exists = rs.next(); // Trả về true nếu tìm thấy tên người dùng
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return exists;
	}
}
